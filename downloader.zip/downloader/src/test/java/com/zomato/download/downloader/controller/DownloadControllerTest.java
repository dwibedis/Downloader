package com.zomato.download.downloader.controller;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

import com.zomato.download.downloader.entity.Download;
import com.zomato.download.downloader.entity.DownloadAbs;
import com.zomato.download.downloader.entity.Status;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class DownloadControllerTest {

	@LocalServerPort
	private int port;

	RestTemplate restTemplate = new RestTemplate();
	HttpHeaders headers = new HttpHeaders();

	@AfterClass
	public static void tearDown() {

	}

	@Test
	public void testDownload() throws Exception {
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);
		ResponseEntity<Download> response = restTemplate.exchange(
				createURLWithPort("/download?fileUrl=sftp://demo:password@test.rebex.net/pub/example/pocketftp.png"),
				HttpMethod.GET, entity, Download.class);
		DownloadAbs download = response.getBody();
		System.out.println(download.getLocalUrl());
		System.out.println(download.getFileName());
		Assert.assertEquals(Status.NOT_YET_STARTED, download.getDownloadStatus());
		Assert.assertTrue(response.getBody() instanceof DownloadAbs);
	}
	
	private String createURLWithPort(String uri) {
        return "http://localhost:" + port + uri;
    }
}
