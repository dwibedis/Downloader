package com.zomato.download.downloader.downloaders;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.net.ConnectException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zomato.download.downloader.entity.DownloadAbs;
import com.zomato.download.downloader.entity.Status;
import com.zomato.download.downloader.model.DownloadAttrs;
import com.zomato.download.downloader.protocols.Protocol;
import com.zomato.download.downloader.repository.DownloadRepo;

import junit.framework.Assert;

@RunWith(SpringJUnit4ClassRunner.class)
public class HTTPDownloaderTest {

	@InjectMocks
	private HTTPDownloader httpDownloader;

	private URL url;

	@Mock
	private DownloadRepo downloadRepo;

	@Mock
	private URLConnection urlConnection;

	private DownloadAttrs attrs;
	private DownloadAbs download;

	private DownloadAbs getEntity(DownloadAttrs downloadAttrs) {
		DownloadAbs download = new DownloadAbs();
		download.setDownloadStatus(Status.NOT_YET_STARTED);
		download.setFileName(downloadAttrs.getFileName());
		download.setRemoteUrl(
				downloadAttrs.getProtocol().getName() + "://" + downloadAttrs.getHost() + downloadAttrs.getUrl());
		return download;
	}

	@Before
	public void doSetUp() throws NoSuchFieldException, SecurityException, IOException {
		attrs = getDownloadAttrs();
		download = getEntity(attrs);
		url = getMockUrl();
		Field field = HTTPDownloader.class.getDeclaredField("destination");
		field.setAccessible(true);

		try {
			field.set(httpDownloader, "/Users/zomato/Downloads/appDwnld");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private DownloadAttrs getDownloadAttrs() {
		DownloadAttrs attrs = new DownloadAttrs();
		attrs.setProtocol(Protocol.HTTP);
		attrs.setFileName("testFile.doc");
		attrs.setHost("testHost");
		attrs.setUrl("testUrl");
//		attrs.setFileName("testFileName");
		return attrs;
	}

	@Test
	public void testIOException() throws IOException {
		HTTPDownloader downloader = Mockito.spy(httpDownloader);

		Mockito.doReturn(getMockConnectionExceptionUrl()).when(downloader).getUrl(Mockito.any(DownloadAttrs.class));

		try {
			downloader.download(attrs, download);
			Assert.fail("Expected exception!!");
		} catch (ConnectException ce) {
			Assert.assertEquals("Error while establishing connection!!", ce.getMessage());
		}
	}

	@Test
	public void test() throws MalformedURLException  {
		HTTPDownloader downloader = Mockito.spy(httpDownloader);

		Mockito.doReturn(url).when(downloader).getUrl(Mockito.any(DownloadAttrs.class));

		Future<Boolean> res = null;
		try {
			res = downloader.download(attrs, download);
		} catch (ConnectException ce) {
			Assert.fail("Exception occured!!");
		}
		
		Assert.assertTrue(res.isDone());
		
		try {
			Assert.assertTrue(res.get());
		} catch (InterruptedException | ExecutionException e) {
			Assert.fail("Exception occured!!");
		}
	}

	@Test
	public void testMalFormedUrl() throws MalformedURLException {
		HTTPDownloader downloader = Mockito.spy(httpDownloader);
		Mockito.doThrow(MalformedURLException.class).when(downloader).getUrl(Mockito.any(DownloadAttrs.class));

		try {
			downloader.download(attrs, download);
			Assert.fail("Expected exception!!");
		} catch (ConnectException ce) {
			Assert.assertEquals("Invalid URL!!", ce.getMessage());
		}
	}

	public URL getMockUrl() throws IOException {

		final URLConnection mockConnection = Mockito.mock(URLConnection.class);
		Mockito.when(mockConnection.getContentLengthLong()).thenReturn(1L);
		InputStream input = Mockito.mock(InputStream.class);
		Mockito.when(mockConnection.getInputStream()).thenReturn(input);
		final URLStreamHandler handler = new URLStreamHandler() {

			@Override
			protected URLConnection openConnection(final URL arg0) throws IOException {
				return mockConnection;
			}
		};
		final URL url = new URL("http://foo.bar", "foo.bar", 80, "", handler);
		return url;
	}

	private URL getMockConnectionExceptionUrl() throws IOException {

		final URLStreamHandler handler = new URLStreamHandler() {

			@Override
			protected URLConnection openConnection(final URL arg0) throws IOException {
				throw new IOException();
			}
		};
		final URL url = new URL("http://foo.bar", "foo.bar", 80, "", handler);
		return url;
	}
}
