package com.zomato.download.downloader.protocols;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zomato.download.downloader.model.DownloadAttrs;

import junit.framework.Assert;

@RunWith(SpringJUnit4ClassRunner.class)
public class DownloadAttrsHelperTest {

	@InjectMocks
	private DownloadAttrsHelper downloadAttrsHelper;

	@Test
	public void testGetProtocolFtp() {
		Protocol protocol = DownloadAttrsHelper.getProtocol("ftp:\\randomurl");
		Assert.assertEquals(Protocol.FTP.getName(), protocol.getName());
	}

	@Test
	public void testGetProtocolSftp() {
		Protocol protocol = DownloadAttrsHelper.getProtocol("sftp:\\randomurl");
		Assert.assertEquals(Protocol.SFTP.getName(), protocol.getName());

	}

	@Test
	public void testGetProtocolHttp() {
		Protocol protocol = DownloadAttrsHelper.getProtocol("http:\\randomurl");
		Assert.assertEquals(Protocol.HTTP.getName(), protocol.getName());
	}

	@Test
	public void testGetProtocolHttps() {
		Protocol protocol = DownloadAttrsHelper.getProtocol("https:\\randomurl");
		Assert.assertEquals(Protocol.HTTPS.getName(), protocol.getName());
	}

	@Test
	public void testGetDownloadAttrsFtp() {
		DownloadAttrs attrs = downloadAttrsHelper.getDownloadAttrs(getUrl(Protocol.FTP), Protocol.FTP);
		
		Assert.assertEquals("host", attrs.getHost());
		Assert.assertEquals("/path1/path2/testFTP.jpg", attrs.getUrl());
		Assert.assertEquals(Protocol.FTP, attrs.getProtocol());
		Assert.assertEquals("testFTP.jpg", attrs.getFileName());
		Assert.assertEquals("user", attrs.getCredentials().getUsername());
		Assert.assertEquals("password", attrs.getCredentials().getPassword());
	}

	@Test
	public void testGetDownloadAttrsSftp() {
		DownloadAttrs attrs = downloadAttrsHelper.getDownloadAttrs(getUrl(Protocol.SFTP), Protocol.SFTP);
		
		Assert.assertEquals("host", attrs.getHost());
		Assert.assertEquals("/path1/path2/testSFTP.jpg", attrs.getUrl());
		Assert.assertEquals(Protocol.SFTP, attrs.getProtocol());
		Assert.assertEquals("testSFTP.jpg", attrs.getFileName());
		Assert.assertEquals("user", attrs.getCredentials().getUsername());
		Assert.assertEquals("password", attrs.getCredentials().getPassword());
	}

	@Test
	public void testGetDownloadAttrsHttp() {
		DownloadAttrs attrs = downloadAttrsHelper.getDownloadAttrs(getUrl(Protocol.HTTP), Protocol.HTTP);
		
		Assert.assertEquals("host", attrs.getHost());
		Assert.assertEquals("/path1/path2/testHTTP.jpg", attrs.getUrl());
		Assert.assertEquals(Protocol.HTTP, attrs.getProtocol());
		Assert.assertEquals("testHTTP.jpg", attrs.getFileName());
	}

	@Test
	public void testURISyntaxException() {
		try {			
			downloadAttrsHelper.getDownloadAttrs(getUrl(Protocol.UNSUPPORTED), Protocol.UNSUPPORTED);
			Assert.fail("Expected exception!!");
		} catch (IllegalArgumentException ie) {
			Assert.assertEquals("Invalid URI syntax", ie.getMessage());
		}
	}
	
	private String getUrl(Protocol protocol) {
		switch (protocol) {
		case FTP:
			return "ftp://user:password@host/path1/path2/testFTP.jpg";
		case SFTP:
			return "ftp://user:password@host:22/path1/path2/testSFTP.jpg";
		case HTTP:
			return "http://host/path1/path2/testHTTP.jpg";
		case HTTPS:
			return "https://host/path1/path2/testHTTPS.jpg";
		default:
			return "random non url";
		}
	}
}
