package com.zomato.download.downloader.downloaders;

import java.io.IOException;
import java.net.ConnectException;
import java.util.concurrent.CompletableFuture;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zomato.download.downloader.entity.DownloadAbs;
import com.zomato.download.downloader.entity.Status;
import com.zomato.download.downloader.exception.ConnectionException;
import com.zomato.download.downloader.model.Credentials;
import com.zomato.download.downloader.model.DownloadAttrs;
import com.zomato.download.downloader.protocols.Protocol;

import junit.framework.Assert;

@RunWith(SpringJUnit4ClassRunner.class)
public class DownloadManagerTest {

	@InjectMocks
	private DownloadManager downloadManager;

	@Mock
	private FTPDownloader ftpDownloader;

	@Mock
	private SFTPDownloader sftpDownloader;

	@Mock
	private HTTPDownloader httpDownloader;

	@Mock
	private HTTPSDownloader httpsDownloader;

	private DownloadAttrs attrs;
	private DownloadAbs download;

	private DownloadAbs getEntity(DownloadAttrs downloadAttrs) {
		DownloadAbs download = new DownloadAbs();
		download.setDownloadStatus(Status.NOT_YET_STARTED);
		download.setFileName(downloadAttrs.getFileName());
		download.setRemoteUrl(downloadAttrs.getProtocol().getName() + "://" + downloadAttrs.getHost() + downloadAttrs.getUrl());
		return download;
	}

	@Test
	public void downloadFtpTestFalse() throws ConnectionException, IOException {

		attrs = getDownloadAttrs(Protocol.FTP);
		download = getEntity(attrs);

		try {
			Mockito.when(ftpDownloader.download(attrs, download)).thenReturn(CompletableFuture.completedFuture(false));
			downloadManager.download(download, attrs, Protocol.FTP);
		} catch (Exception e) {
			Assert.fail("Exception occured!!");
		}

		Mockito.verify(ftpDownloader).download(attrs, download);
	}

	@Test
	public void downloadFtpTestTrue() throws ConnectionException, IOException {
		
		attrs = getDownloadAttrs(Protocol.FTP);
		download = getEntity(attrs);

		try {
			Mockito.when(ftpDownloader.download(attrs, download)).thenReturn(CompletableFuture.completedFuture(true));
			downloadManager.download(download,attrs, Protocol.FTP);
		} catch (Exception e) {
			Assert.fail("Exception occured!!");
		}
		
		Mockito.verify(ftpDownloader).download(attrs, download);
	}

	@Test
	public void downloadSftpTestTrue() throws ConnectionException {
		
		attrs = getDownloadAttrs(Protocol.SFTP);
		download = getEntity(attrs);

		try {
			Mockito.when(sftpDownloader.download(attrs, download)).thenReturn(CompletableFuture.completedFuture(true));
			downloadManager.download(download, attrs, Protocol.SFTP);
		} catch (Exception e) {
			Assert.fail("Exception occured!!");
		}

		Mockito.verify(sftpDownloader).download(attrs, download);
	}

	@Test
	public void downloadSftpTestFalse() throws ConnectionException {
		
		attrs = getDownloadAttrs(Protocol.SFTP);
		download = getEntity(attrs);

		try {
			Mockito.when(sftpDownloader.download(attrs, download)).thenReturn(CompletableFuture.completedFuture(false));
			downloadManager.download(download, attrs, Protocol.SFTP);
		} catch (Exception e) {
			Assert.fail("Exception occured!!");
		}

		Mockito.verify(sftpDownloader).download(attrs, download);
	}

	@Test
	public void downloadHttpTestFalse() throws ConnectionException, ConnectException {

		attrs = getDownloadAttrs(Protocol.HTTP);
		download = getEntity(attrs);

		try {
			Mockito.when(httpDownloader.download(attrs, download)).thenReturn(CompletableFuture.completedFuture(false));
			downloadManager.download(download, attrs, Protocol.HTTP);
		} catch (Exception e) {
			Assert.fail("Exception occured!!");
		}
		
		Mockito.verify(httpDownloader).download(attrs, download);

	}

	@Test
	public void downloadHttpTestTrue() throws ConnectException {

		attrs = getDownloadAttrs(Protocol.HTTP);
		download = getEntity(attrs);

		try {
			Mockito.when(httpDownloader.download(attrs, download)).thenReturn(CompletableFuture.completedFuture(false));
			downloadManager.download(download, attrs, Protocol.HTTP);
		} catch (Exception e) {
			Assert.fail("Exception occured!!");
		}
		
		Mockito.verify(httpDownloader).download(attrs, download);
	}

	@Test
	public void downloadHttpsTestTrue() throws ConnectException {
		
		attrs = getDownloadAttrs(Protocol.HTTPS);
		download = getEntity(attrs);

		try {
			Mockito.when(httpsDownloader.download(attrs, download)).thenReturn(CompletableFuture.completedFuture(false));
			downloadManager.download(download, attrs, Protocol.HTTPS);
		} catch (Exception e) {
			Assert.fail("Exception occured!!");
		}
		Mockito.verify(httpsDownloader).download(attrs, download);
	}

	@Test
	public void downloadHttpsTestFalse() throws ConnectException {
		
		attrs = getDownloadAttrs(Protocol.HTTPS);
		download = getEntity(attrs);

		try {
			Mockito.when(httpsDownloader.download(attrs, download)).thenReturn(CompletableFuture.completedFuture(false));
			downloadManager.download(download, attrs, Protocol.HTTPS);
		} catch (Exception e) {
			Assert.fail("Exception occured!!");
		}
		Mockito.verify(httpsDownloader).download(attrs, download);
	}

	@Test
	public void downloadExceptionTest() {

		attrs = getDownloadAttrs(Protocol.UNSUPPORTED);
		download = getEntity(attrs);

		try {			
			downloadManager.download(download, attrs, Protocol.UNSUPPORTED);
		} catch (IllegalArgumentException ie) {
			Assert.assertEquals("Protocol Not Supported", ie.getMessage());
		} catch (Exception e) {
			Assert.fail("Invalid Exception occured!!");
		}
	}

	private DownloadAttrs getDownloadAttrs(Protocol protocol) {
		DownloadAttrs attrs = new DownloadAttrs();
		attrs.setProtocol(protocol);
		attrs.setFileName("testFileName");
		attrs.setHost("testHost");
		attrs.setCredentials(getCreds());
		attrs.setUrl("testUrl");
		return attrs;
	}

	private Credentials getCreds() {
		Credentials credentials = new Credentials();
		credentials.setUsername("testUser");
		credentials.setPassword("testPass");
		return credentials;
	}
}
