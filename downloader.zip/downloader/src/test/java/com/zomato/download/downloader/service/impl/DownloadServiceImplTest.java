package com.zomato.download.downloader.service.impl;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zomato.download.downloader.downloaders.DownloadManager;
import com.zomato.download.downloader.entity.Download;
import com.zomato.download.downloader.entity.DownloadAbs;
import com.zomato.download.downloader.entity.Status;
import com.zomato.download.downloader.model.Credentials;
import com.zomato.download.downloader.model.DownloadAttrs;
import com.zomato.download.downloader.model.DownloadDTO;
import com.zomato.download.downloader.protocols.DownloadAttrsHelper;
import com.zomato.download.downloader.protocols.Protocol;
import com.zomato.download.downloader.repository.DownloadRepo;

import junit.framework.Assert;

@RunWith(SpringJUnit4ClassRunner.class)
public class DownloadServiceImplTest {

	@InjectMocks
	private DownloadServiceImpl downloadServiceImpl;

	@Mock
	private DownloadManager downloadManager;

	@Mock
	private DownloadAttrsHelper downloadAttrsHelper;

	@Mock
	private DownloadRepo downloadRepo;

	private DownloadAbs download;
	private DownloadAttrs attrs;

	private DownloadAbs getEntity(DownloadAttrs downloadAttrs) {
		Download download = new Download();
		download.setDownloadId(2);
		download.setDownloadStatus(Status.NOT_YET_STARTED);
		download.setFileName(downloadAttrs.getFileName());
		download.setRemoteUrl(downloadAttrs.getProtocol().getName() + "://" + downloadAttrs.getHost() + downloadAttrs.getUrl());
		return download;
	}

	@Before
	public void doSetUp() {
		attrs  = getDownloadAttrs();
		download = getEntity(attrs);
	}

	private DownloadAttrs getDownloadAttrs() {
		DownloadAttrs attrs = new DownloadAttrs();
		attrs.setProtocol(Protocol.FTP);
		attrs.setFileName("test.zip");
		attrs.setHost("host");
		attrs.setCredentials(getCreds());
		attrs.setUrl("/path/test.zip");
		return attrs;
	}

	private Credentials getCreds() {
		Credentials credentials = new Credentials();
		credentials.setUsername("user");
		credentials.setPassword("password");
		return credentials;
	}

	@Test
	public void testDwonload() throws Exception {
		Mockito.when(downloadAttrsHelper.getDownloadAttrs("ftp://user:password@host/path/test.zip", Protocol.FTP)).thenReturn(attrs);
		Mockito.doNothing().when(downloadManager).download(download, attrs, Protocol.FTP);
		Mockito.when(downloadRepo.save(Mockito.any(DownloadAbs.class))).thenReturn(download);

		DownloadDTO download = downloadServiceImpl.download("ftp://user:password@host/path/test.zip");
		
		Assert.assertEquals("test.zip", download.getFileName());
	}

	@Test
	public void testDwonloadException() throws Exception {
		Mockito.doThrow(IllegalArgumentException.class).when(downloadManager).download(download, attrs, Protocol.FTP);
		Mockito.when(downloadAttrsHelper.getDownloadAttrs("ftp://user:password@host/path/test.zip", Protocol.FTP)).thenReturn(attrs);
		Mockito.when(downloadRepo.save(Mockito.any(DownloadAbs.class))).thenReturn(download);
		
		try {
			downloadServiceImpl.download("ftp://user:password@host/path/test.zip");
			Assert.fail("Expected Exception!!");
		} catch (IllegalArgumentException ie) {
			Assert.assertEquals("Some error occured!!", ie.getMessage());
		}
	}

	@Test
	public void testDwonloadUnsupportedException() throws Exception {
		
		try {
			downloadServiceImpl.download("randomurl");
			Assert.fail("Expected Exception!!");
		} catch (IllegalArgumentException ie) {
			Assert.assertEquals("protocol not supported!!", ie.getMessage());
		}
	}

}
