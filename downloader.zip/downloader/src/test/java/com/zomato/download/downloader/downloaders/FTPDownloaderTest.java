package com.zomato.download.downloader.downloaders;

import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.net.SocketException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.apache.commons.net.ftp.FTPClient;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.zomato.download.downloader.entity.DownloadAbs;
import com.zomato.download.downloader.entity.Status;
import com.zomato.download.downloader.exception.ConnectionException;
import com.zomato.download.downloader.model.Credentials;
import com.zomato.download.downloader.model.DownloadAttrs;
import com.zomato.download.downloader.protocols.Protocol;
import com.zomato.download.downloader.repository.DownloadRepo;

import junit.framework.Assert;

@RunWith(SpringJUnit4ClassRunner.class)
public class FTPDownloaderTest {

	@InjectMocks
	private FTPDownloader ftpDownloader;

	@Mock
	private FTPClient ftpClient;

	@Mock
	private DownloadRepo downloadRepo;

	private DownloadAttrs attrs;
	private DownloadAbs download;

	private DownloadAbs getEntity(DownloadAttrs downloadAttrs) {
		DownloadAbs download = new DownloadAbs();
		download.setDownloadStatus(Status.NOT_YET_STARTED);
		download.setFileName(downloadAttrs.getFileName());
		download.setRemoteUrl(
				downloadAttrs.getProtocol().getName() + "://" + downloadAttrs.getHost() + downloadAttrs.getUrl());
		return download;
	}

	@Before
	public void doSetUp()
			throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException {
		attrs = getDownloadAttrs();
		download = getEntity(attrs);

		Field field = FTPDownloader.class.getDeclaredField("ftp");
		field.setAccessible(true);

		try {
			field.set(ftpDownloader, ftpClient);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private DownloadAttrs getDownloadAttrs() {
		DownloadAttrs attrs = new DownloadAttrs();
		attrs.setProtocol(Protocol.FTP);
		attrs.setFileName("testFileName.ext");
		attrs.setHost("testHost");
		attrs.setCredentials(getCreds());
		attrs.setUrl("testUrl");
		return attrs;
	}

	private Credentials getCreds() {
		Credentials credentials = new Credentials();
		credentials.setUsername("testUser");
		credentials.setPassword("testPass");
		return credentials;
	}

	@Test
	public void testDownloadTrue() throws SocketException, IOException {
		Mockito.doNothing().when(ftpClient).connect("testHost");
		Mockito.when(ftpClient.getReplyCode()).thenReturn(250);
		Mockito.when(ftpClient.retrieveFile(Mockito.matches("testUrl"), Mockito.any(FileOutputStream.class)))
				.thenReturn(true);
		Mockito.when(ftpClient.getReplyString()).thenReturn("213 56789");
		Mockito.when(downloadRepo.save(Mockito.any(DownloadAbs.class))).thenReturn(download);

		Future<Boolean> res = null;
		try {
			res = ftpDownloader.download(attrs, download);
		} catch (ConnectionException e) {
			Assert.fail("Exception Occured!!");
		}

		Assert.assertTrue(res.isDone());

		try {
			Assert.assertTrue(res.get().booleanValue());
		} catch (InterruptedException e) {
			Assert.fail("Interrupted Exception Occured!!");
		} catch (ExecutionException e) {
			Assert.fail("Execution Exception Occured!!");
		}
	}

	@Test
	public void testDownloadFalse() throws SocketException, IOException {
		Mockito.doNothing().when(ftpClient).connect("testHost");
		// TODO return any num between 200 and 300
		Mockito.when(ftpClient.getReplyCode()).thenReturn(250);
		Mockito.when(ftpClient.retrieveFile(Mockito.matches("testUrl"), Mockito.any(FileOutputStream.class)))
				.thenReturn(false);
		Mockito.when(ftpClient.getReplyString()).thenReturn("213 56789");
		Mockito.when(downloadRepo.save(Mockito.any(DownloadAbs.class))).thenReturn(download);

		Future<Boolean> res = null;
		try {
			res = ftpDownloader.download(attrs, download);
		} catch (ConnectionException e) {
			Assert.fail("Exception Occured!!");
		}

		Assert.assertTrue(res.isDone());

		try {
			Assert.assertFalse(res.get().booleanValue());
		} catch (InterruptedException e) {
			Assert.fail("Interrupted Exception Occured!!");
		} catch (ExecutionException e) {
			Assert.fail("Execution Exception Occured!!");
		}
	}

	@Test
	public void testDownloadBadReplyCode() throws SocketException, IOException {
		Mockito.doNothing().when(ftpClient).connect("testHost");
		// TODO return any num not in between 200 and 300
		Mockito.when(ftpClient.getReplyCode()).thenReturn(169);
		Mockito.when(ftpClient.retrieveFile(Mockito.matches("testUrl"), Mockito.any(FileOutputStream.class)))
				.thenReturn(false);
		Mockito.when(ftpClient.getReplyString()).thenReturn("213 56789");
		Mockito.when(downloadRepo.save(Mockito.any(DownloadAbs.class))).thenReturn(download);

		try {
			ftpDownloader.download(attrs, download);
			Assert.fail("Exception didn't occur!!");
		} catch (ConnectionException ce) {
			Assert.assertEquals("Error while connecting to server", ce.getMessage());
		}
	}

	@Test
	public void testDownloadConnectException() throws SocketException, IOException {
		Mockito.doNothing().when(ftpClient).connect("testHost");
		// TODO return any num between 200 and 300
		Mockito.when(ftpClient.getReplyCode()).thenReturn(250);
		Mockito.doThrow(IOException.class).when(ftpClient).retrieveFile(Mockito.matches("testUrl"),
				Mockito.any(FileOutputStream.class));
		Mockito.when(ftpClient.getReplyString()).thenReturn("213 56789");
		Mockito.when(downloadRepo.save(Mockito.any(DownloadAbs.class))).thenReturn(download);

		try {
			ftpDownloader.download(attrs, download);
			Assert.fail("Exception didn't occur!!");
		} catch (ConnectionException ce) {
			Assert.assertEquals("Error while downloading from server", ce.getMessage());
		}
	}
}
