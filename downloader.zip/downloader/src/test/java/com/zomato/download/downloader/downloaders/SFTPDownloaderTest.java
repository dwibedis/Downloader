package com.zomato.download.downloader.downloaders;

import java.lang.reflect.Field;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import com.zomato.download.downloader.entity.DownloadAbs;
import com.zomato.download.downloader.entity.Status;
import com.zomato.download.downloader.exception.ConnectionException;
import com.zomato.download.downloader.model.Credentials;
import com.zomato.download.downloader.model.DownloadAttrs;
import com.zomato.download.downloader.protocols.Protocol;
import com.zomato.download.downloader.repository.DownloadRepo;

import junit.framework.Assert;

@RunWith(SpringJUnit4ClassRunner.class)
public class SFTPDownloaderTest {

	@InjectMocks
	private SFTPDownloader sftpDownloader;

	@Mock
	private JSch jsch;

	@Mock
	private Session session;

	@Mock
	private ChannelSftp channel;

	@Mock
	private DownloadRepo downloadRepo;

	@Mock
	private SftpATTRS sftpAttrs;

	private DownloadAttrs attrs;
	private DownloadAbs download;

	private DownloadAbs getEntity(DownloadAttrs downloadAttrs) {
		DownloadAbs download = new DownloadAbs();
		download.setDownloadStatus(Status.NOT_YET_STARTED);
		download.setFileName(downloadAttrs.getFileName());
		download.setRemoteUrl(
				downloadAttrs.getProtocol().getName() + "://" + downloadAttrs.getHost() + downloadAttrs.getUrl());
		return download;
	}

	@Before
	public void doSetUp() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException,
			SecurityException, SftpException {
		attrs = getDownloadAttrs();
		download = getEntity(attrs);

		Mockito.when(channel.stat(attrs.getUrl())).thenReturn(sftpAttrs);
		Mockito.when(sftpAttrs.getSize()).thenReturn(1L);

		Field jshField = SFTPDownloader.class.getDeclaredField("jsch");
		Field destination = SFTPDownloader.class.getDeclaredField("destination");
		jshField.setAccessible(true);
		destination.setAccessible(true);
		try {
			jshField.set(sftpDownloader, jsch);
			destination.set(sftpDownloader, new String());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private DownloadAttrs getDownloadAttrs() {
		DownloadAttrs attrs = new DownloadAttrs();
		attrs.setProtocol(Protocol.SFTP);
		attrs.setFileName("testFileName.ext");
		attrs.setHost("testHost");
		attrs.setCredentials(getCreds());
		attrs.setUrl("testUrl");
		return attrs;
	}

	private Credentials getCreds() {
		Credentials credentials = new Credentials();
		credentials.setUsername("testUser");
		credentials.setPassword("testPass");
		return credentials;
	}

	@Test
	public void testTrue() throws JSchException, SftpException {
		Mockito.when(jsch.getSession("testUser", "testHost")).thenReturn(session);
		Mockito.doNothing().when(session).connect();
		Mockito.when(session.openChannel(Protocol.SFTP.getName())).thenReturn(channel);
		Mockito.doNothing().when(channel).connect();
		Mockito.doNothing().when(channel).get(Mockito.anyString(), Mockito.anyString());
		Mockito.when(downloadRepo.save(Mockito.any(DownloadAbs.class))).thenReturn(download);

		Future<Boolean> res = null;
		try {
			res = sftpDownloader.download(attrs, download);
		} catch (ConnectionException e) {
			Assert.fail("Exception Occured!!");
		}
		Assert.assertTrue(res.isDone());
		try {
			Assert.assertTrue(res.get().booleanValue());
		} catch (InterruptedException | ExecutionException e) {
			Assert.fail("Unexpected exception Occured!!");
		}
	}

	@Test
	public void testGetSessionException() throws JSchException, SftpException {
		Mockito.doThrow(JSchException.class).when(jsch).getSession("testUser", "testHost");

		try {
			sftpDownloader.download(attrs, download);
			Assert.fail("Exception did not occur!!");
		} catch (ConnectionException e) {
			Assert.assertEquals("Error while connecting to Server", e.getMessage());
		}
	}

	@Test
	public void testSessionConnectException() throws JSchException, SftpException {
		Mockito.when(jsch.getSession("testUser", "testHost")).thenReturn(session);
		Mockito.doThrow(JSchException.class).when(session).connect();

		try {
			sftpDownloader.download(attrs, download);
			Assert.fail("Exception did not occur!!");
		} catch (ConnectionException e) {
			Assert.assertEquals("Error while connecting to Server", e.getMessage());
		}
	}

	@Test
	public void testChannelConnectException() throws JSchException, SftpException {
		Mockito.when(jsch.getSession("testUser", "testHost")).thenReturn(session);
		Mockito.doNothing().when(session).connect();
		Mockito.doThrow(JSchException.class).when(session).openChannel(Protocol.SFTP.getName());

		try {
			sftpDownloader.download(attrs, download);
			Assert.fail("Exception did not occur!!");
		} catch (ConnectionException e) {
			Assert.assertEquals("Error while connecting to Server", e.getMessage());
		}
	}

	@Test
	public void testSftpException() throws JSchException, SftpException {
		Mockito.when(jsch.getSession("testUser", "testHost")).thenReturn(session);
		Mockito.doNothing().when(session).connect();
		Mockito.when(session.openChannel(Protocol.SFTP.getName())).thenReturn(channel);
		Mockito.doNothing().when(channel).connect();
		Mockito.doThrow(SftpException.class).when(channel).get(Mockito.anyString(), Mockito.anyString());

		try {
			sftpDownloader.download(attrs, download);
			Assert.fail("Exception did not occur!!");
		} catch (ConnectionException e) {
			Assert.assertEquals("Error while fetching the file", e.getMessage());
		}
	}
}
