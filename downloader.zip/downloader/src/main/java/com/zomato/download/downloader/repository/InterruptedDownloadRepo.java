package com.zomato.download.downloader.repository;

import org.springframework.data.repository.CrudRepository;

import com.zomato.download.downloader.entity.DownloadAbs;

public interface InterruptedDownloadRepo extends CrudRepository<DownloadAbs, Long> {

}
