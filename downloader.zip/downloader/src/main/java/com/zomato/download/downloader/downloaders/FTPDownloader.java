package com.zomato.download.downloader.downloaders;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;

import org.apache.commons.net.PrintCommandListener;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.zomato.download.downloader.constants.AppConstants;
import com.zomato.download.downloader.entity.DownloadAbs;
import com.zomato.download.downloader.entity.Status;
import com.zomato.download.downloader.exception.ConnectionException;
import com.zomato.download.downloader.model.DownloadAttrs;
import com.zomato.download.downloader.repository.DownloadRepo;
import com.zomato.download.downloader.utils.FileUtils;

/**
 * the downloader to download files from ftp.
 * 
 * @author zomato
 *
 */
@Component
public class FTPDownloader {

	@Autowired
	private DownloadRepo downloadRepo;

	private FTPClient ftp = new FTPClient();	

	@Value("${download.destination}")
	private String destination;

	/**
	 * method to download file from given ftp location.
	 * 
	 * @param downloadAttrs the download attributes
	 * @param download
	 * @return status
	 * @throws ConnectionException
	 * @throws IOException
	 */
	@Async
	public Future<Boolean> download(DownloadAttrs downloadAttrs, DownloadAbs download)
			throws ConnectionException, IOException {

		ftp.addProtocolCommandListener(new PrintCommandListener(new PrintWriter(System.out)));

		int reply;
		boolean isSuccess = false;

		ftp.connect(downloadAttrs.getHost());
		reply = ftp.getReplyCode();

		//the reply code for success lies between 200 and 300
		if (!FTPReply.isPositiveCompletion(reply)) {
			ftp.disconnect();
			throw new ConnectionException("Error while connecting to server");
		}

		ftp.login(downloadAttrs.getCredentials().getUsername(), downloadAttrs.getCredentials().getPassword());
		
		ftp.setFileType(FTP.BINARY_FILE_TYPE);
		
		ftp.enterLocalPassiveMode();

		ftp.sendCommand(AppConstants.FTP_SIZE_COMMAND, downloadAttrs.getUrl());
		
		long fileSize = Long.parseLong(ftp.getReplyString().split(" ")[1].trim());
		AppConstants.FILE_SIZE_MAP.put(download.getDownloadId(), fileSize);
		download.setFileSize(fileSize);

		File destinationFile = FileUtils.getAppropiateFile(new File(destination, downloadAttrs.getFileName()));
		
		try (FileOutputStream fos = new FileOutputStream(destinationFile)) {
			
			download.setDownloadStatus(Status.IN_PROGRESS);
			download.setLocalUrl(destinationFile.getAbsolutePath());
			downloadRepo.save(download);
			
			isSuccess = ftp.retrieveFile(downloadAttrs.getUrl(), fos);
			
			return CompletableFuture.completedFuture(isSuccess);
		
		} catch (IOException e) {
			
			download.setDownloadStatus(Status.INTERRUPTED);
			downloadRepo.save(download);
			
			throw new ConnectionException("Error while downloading from server");
		
		} finally {
			
			AppConstants.FILE_SIZE_MAP.remove(download.getDownloadId());
			
			ftp.logout();
			ftp.disconnect();
			
			if (isSuccess) {
				download.setDownloadStatus(Status.DONE);
				downloadRepo.save(download);
			} else {
				download.setDownloadStatus(Status.INTERRUPTED);
				downloadRepo.save(download);
			}
		
		}
	}
}
