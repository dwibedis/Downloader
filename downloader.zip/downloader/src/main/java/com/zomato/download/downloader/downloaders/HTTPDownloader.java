package com.zomato.download.downloader.downloaders;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.ConnectException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.zomato.download.downloader.constants.AppConstants;
import com.zomato.download.downloader.entity.DownloadAbs;
import com.zomato.download.downloader.entity.Status;
import com.zomato.download.downloader.model.DownloadAttrs;
import com.zomato.download.downloader.protocols.Protocol;
import com.zomato.download.downloader.repository.DownloadRepo;
import com.zomato.download.downloader.utils.FileUtils;

/**
 * utility to download file from specified HTTP location.
 * 
 * @author zomato
 *
 */
@Component
public class HTTPDownloader {

	@Autowired
	private DownloadRepo downloadRepo;

	@Value("${download.destination}")
	private String destination;

	/**
	 * method to download file from given HTTP location.
	 * 
	 * @param downloadAttrs
	 * @param download
	 * @return
	 * @throws ConnectException
	 */
	@Async
	public Future<Boolean> download(DownloadAttrs downloadAttrs, DownloadAbs download) throws ConnectException {
		URL url;
		long fileSize;

		try {
			url = getUrl(downloadAttrs);
		} catch (MalformedURLException e1) {
			throw new ConnectException("Invalid URL!!");
		}

		File destinastionFile = FileUtils.getAppropiateFile(new File(destination, downloadAttrs.getFileName()));
		download.setDownloadStatus(Status.IN_PROGRESS);

		try {

			fileSize = url.openConnection().getContentLengthLong();
			AppConstants.FILE_SIZE_MAP.put(download.getDownloadId(), fileSize);
			download.setFileSize(fileSize);

		} catch (IOException e1) {

			download.setDownloadStatus(Status.INTERRUPTED);
			downloadRepo.save(download);

			throw new ConnectException("Error while establishing connection!!");

		}

		download.setLocalUrl(destinastionFile.getAbsolutePath());
		downloadRepo.save(download);

		try (BufferedInputStream bis = new BufferedInputStream(url.openStream());
				FileOutputStream fis = new FileOutputStream(destinastionFile);) {

			byte[] buffer = new byte[1024];
			int count = 0;

			while ((count = bis.read(buffer, 0, 1024)) != -1) {
				fis.write(buffer, 0, count);
			}

			download.setDownloadStatus(Status.DONE);
			downloadRepo.save(download);

			return CompletableFuture.completedFuture(true);

		} catch (IOException e) {

			e.printStackTrace();
			download.setDownloadStatus(Status.INTERRUPTED);
			downloadRepo.save(download);

			throw new ConnectException("Error while downloading!!");

		} finally {

			AppConstants.FILE_SIZE_MAP.remove(download.getDownloadId());

		}
	}

	public URL getUrl(DownloadAttrs downloadAttrs) throws MalformedURLException {
		return new URL(Protocol.HTTP.getName() + AppConstants.URL_SEPARATOR
				+ downloadAttrs.getHost().concat(downloadAttrs.getUrl()));
	}

}
