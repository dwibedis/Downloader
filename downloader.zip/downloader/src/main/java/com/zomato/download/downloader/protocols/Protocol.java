package com.zomato.download.downloader.protocols;

/**
 * Supported protocols in module.
 * 
 * @author zomato
 *
 */
public enum Protocol {

	FTP("ftp"), HTTPS("https"), SFTP("sftp"), HTTP("http"), UNSUPPORTED("protocol not supported");

	private String name;

	Protocol(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
}
