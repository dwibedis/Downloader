package com.zomato.download.downloader.scheduler;

import java.io.File;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.util.Files;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.zomato.download.downloader.entity.DownloadAbs;
import com.zomato.download.downloader.entity.Status;
import com.zomato.download.downloader.repository.DownloadRepo;
import com.zomato.download.downloader.repository.InterruptedDownloadRepo;

/**
 * clean up utility.
 * 
 * @author zomato
 *
 */
@Component
@EnableScheduling
public class CleanUp {

	private static final Logger logger = LogManager.getLogger(CleanUp.class);

	@Autowired
	private DownloadRepo downloadRepo;

	@Autowired
	private InterruptedDownloadRepo interruptedRepo;
	/**
	 * method to delete all interrupted files.
	 */
	@Scheduled(fixedRate = 30000, initialDelay = 0)
	public void cleanUpFiles() {
		
		logger.info("Starting cleanup process......");
		List<DownloadAbs> interruptedFiles = downloadRepo.findByDownloadStatus(Status.INTERRUPTED);
		
		for (DownloadAbs download : interruptedFiles) {
			
			String localPath = download.getLocalUrl();
			
			if (!StringUtils.isEmpty(localPath)) {
				
				File file = new File(download.getLocalUrl());
				
				if (file.exists()) {
					logger.info("Deleting file : " + file.getName());
					Files.delete(file);
				}
			
			}
		
		}
		
		logger.info("Deleting : " + interruptedFiles.size() + " entities");
		downloadRepo.deleteAll(interruptedFiles);
		logger.info("inserting : " + interruptedFiles.size() + " entities");
		interruptedRepo.saveAll(interruptedFiles);
	}
}
