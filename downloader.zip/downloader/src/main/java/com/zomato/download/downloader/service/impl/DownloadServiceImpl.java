package com.zomato.download.downloader.service.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zomato.download.downloader.downloaders.DownloadManager;
import com.zomato.download.downloader.entity.Download;
import com.zomato.download.downloader.entity.DownloadAbs;
import com.zomato.download.downloader.entity.Status;
import com.zomato.download.downloader.model.DownloadAttrs;
import com.zomato.download.downloader.model.DownloadDTO;
import com.zomato.download.downloader.protocols.DownloadAttrsHelper;
import com.zomato.download.downloader.protocols.Protocol;
import com.zomato.download.downloader.repository.DownloadRepo;
import com.zomato.download.downloader.service.DownloadService;

@Service
public class DownloadServiceImpl implements DownloadService {

	@Autowired
	private DownloadManager downloadManager;

	@Autowired
	private DownloadRepo downloadRepo;

	@Autowired
	private DownloadAttrsHelper downloadAttrsHelper;

	private static final Logger logger = LogManager.getLogger(DownloadService.class);

	@Override
	public DownloadDTO download(String fileUrl) {
		DownloadDTO downloadDto = new DownloadDTO();
	
		Protocol protocol = DownloadAttrsHelper.getProtocol(fileUrl);
		logger.info("URL protocol : " + protocol);
		
		if (protocol.equals(Protocol.UNSUPPORTED)) {
			throw new IllegalArgumentException("protocol not supported!!");
		}

		DownloadAttrs downloadAttrs = downloadAttrsHelper.getDownloadAttrs(fileUrl, protocol);
		DownloadAbs download = downloadRepo.save(getEntity(downloadAttrs));
		
		try {
			downloadManager.download(download, downloadAttrs, protocol);
			downloadDto.setDownloadId(download.getDownloadId());
			downloadDto.setFileName(download.getFileName());
			return downloadDto;
		} catch (Exception e) {
			throw new IllegalArgumentException("Some error occured!!");
		}
	}

	private DownloadAbs getEntity(DownloadAttrs downloadAttrs) {
		Download download = new Download();
		download.setDownloadStatus(Status.NOT_YET_STARTED);
		download.setFileName(downloadAttrs.getFileName());
		download.setRemoteUrl(downloadAttrs.getProtocol().getName() + "://" + downloadAttrs.getHost() + downloadAttrs.getUrl());
		return download;
	}

}
