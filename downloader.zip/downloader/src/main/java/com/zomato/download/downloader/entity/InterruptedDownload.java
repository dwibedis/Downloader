package com.zomato.download.downloader.entity;

public class InterruptedDownload {

}
