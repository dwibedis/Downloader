package com.zomato.download.downloader.downloaders;

import java.io.File;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import com.zomato.download.downloader.constants.AppConstants;
import com.zomato.download.downloader.entity.DownloadAbs;
import com.zomato.download.downloader.entity.Status;
import com.zomato.download.downloader.exception.ConnectionException;
import com.zomato.download.downloader.model.DownloadAttrs;
import com.zomato.download.downloader.protocols.Protocol;
import com.zomato.download.downloader.repository.DownloadRepo;
import com.zomato.download.downloader.utils.FileUtils;

/**
 * the downloader to download files from sftp.
 * 
 * @author zomato
 *
 */
@Component
public class SFTPDownloader {

	@Autowired
	private DownloadRepo downloadRepo;

	private JSch jsch = new JSch();

	@Value("${download.destination}")
	private String destination;

	/**
	 * method to download file from given sftp location.
	 * 
	 * @param downloadAttrs
	 * @param download
	 * @return
	 * @throws ConnectionException
	 */
	@Async
	public Future<Boolean> download(DownloadAttrs downloadAttrs, DownloadAbs download) throws ConnectionException {

		Session session = null;

		try {
			session = jsch.getSession(downloadAttrs.getCredentials().getUsername(), downloadAttrs.getHost());
			session.setConfig("StrictHostKeyChecking", "no");
			session.setPassword(downloadAttrs.getCredentials().getPassword());
			session.connect();

			Channel channel = session.openChannel(Protocol.SFTP.getName());
			channel.connect();
			ChannelSftp sftpChannel = (ChannelSftp) channel;
			SftpATTRS sftpAttrs = sftpChannel.stat(downloadAttrs.getUrl());

			AppConstants.FILE_SIZE_MAP.put(download.getDownloadId(), sftpAttrs.getSize());

			download.setFileSize(sftpAttrs.getSize());
			download.setDownloadStatus(Status.IN_PROGRESS);
			downloadRepo.save(download);

			File destinationFile = FileUtils.getAppropiateFile(new File(destination, downloadAttrs.getFileName()));
			download.setLocalUrl(destinationFile.getAbsolutePath());

			sftpChannel.get(downloadAttrs.getUrl(), destinationFile.getAbsolutePath());

			download.setDownloadStatus(Status.DONE);
			downloadRepo.save(download);

			sftpChannel.exit();
			session.disconnect();

			return CompletableFuture.completedFuture(true);

		} catch (JSchException e) {

			download.setDownloadStatus(Status.INTERRUPTED);
			downloadRepo.save(download);

			throw new ConnectionException("Error while connecting to Server");

		} catch (SftpException e) {

			download.setDownloadStatus(Status.INTERRUPTED);
			downloadRepo.save(download);

			throw new ConnectionException("Error while fetching the file");

		} finally {

			AppConstants.FILE_SIZE_MAP.remove(download.getDownloadId());

		}
	}

}
