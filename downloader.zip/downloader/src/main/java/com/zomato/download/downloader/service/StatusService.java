package com.zomato.download.downloader.service;

import com.zomato.download.downloader.model.DownloadDTO;

public interface StatusService {

	/**
	 * 
	 * @param download
	 * @return
	 */
	public int getStatus(DownloadDTO download);
}
