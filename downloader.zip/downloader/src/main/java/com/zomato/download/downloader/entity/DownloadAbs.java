package com.zomato.download.downloader.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public abstract class DownloadAbs {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long downloadId;
	private String fileName;
	private long fileSize;
	@Column(name = "download_status")
	@Enumerated(EnumType.STRING)
	private Status downloadStatus;
	private String remoteUrl;
	private String localUrl;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public long getFileSize() {
		return fileSize;
	}

	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}

	public Status getDownloadStatus() {
		return downloadStatus;
	}

	public void setDownloadStatus(Status downloadStatus) {
		this.downloadStatus = downloadStatus;
	}

	public String getRemoteUrl() {
		return remoteUrl;
	}

	public void setRemoteUrl(String sourceUrl) {
		this.remoteUrl = sourceUrl;
	}

	public Long getDownloadId() {
		return downloadId;
	}

	public void setDownloadId(long id) {
		this.downloadId = id;
	}

	public String getLocalUrl() {
		return localUrl;
	}

	public void setLocalUrl(String localUrl) {
		this.localUrl = localUrl;
	}

}
