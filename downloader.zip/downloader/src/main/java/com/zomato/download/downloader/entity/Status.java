package com.zomato.download.downloader.entity;

public enum Status {
	NOT_YET_STARTED, IN_PROGRESS, DONE, INTERRUPTED;
}
