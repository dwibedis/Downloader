package com.zomato.download.downloader;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * application to download files from URLs.
 * 
 * @author zomato
 *
 */
@SpringBootApplication
@EnableAsync
public class Downloader {
	public static void main(String[] args) {
		SpringApplication.run(Downloader.class, args);
	}
}
