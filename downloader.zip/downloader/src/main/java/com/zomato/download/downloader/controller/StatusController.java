package com.zomato.download.downloader.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.zomato.download.downloader.model.DownloadDTO;
import com.zomato.download.downloader.service.StatusService;

@RestController
public class StatusController {

	@Autowired
	private StatusService statusService;

	@GetMapping("/status")
	public Integer getStatus(@RequestBody DownloadDTO download) {
		return statusService.getStatus(download);
	}
}
