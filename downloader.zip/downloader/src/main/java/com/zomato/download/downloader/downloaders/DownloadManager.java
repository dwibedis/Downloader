package com.zomato.download.downloader.downloaders;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.zomato.download.downloader.entity.DownloadAbs;
import com.zomato.download.downloader.model.DownloadAttrs;
import com.zomato.download.downloader.protocols.Protocol;

/**
 * Manager to manage download of files from the URL given.
 * 
 * @author zomato
 *
 */
@Component
public class DownloadManager {

	@Autowired
	private FTPDownloader ftpDownloader;

	@Autowired
	private SFTPDownloader sftpDownloader;

	@Autowired
	private HTTPDownloader httpDownloader;

	@Autowired
	private HTTPSDownloader httpsDownloader;

	/**
	 * method to download files from specified location.
	 * @param download 
	 * 
	 * @param downloadAttrs  the file url
	 * @param protocol the protocol
	 * @return
	 * @throws Exception 
	 */
	public void download(DownloadAbs download, DownloadAttrs downloadAttrs, Protocol protocol) throws Exception {
		
		switch (protocol) {
		
		case FTP:
			ftpDownloader.download(downloadAttrs, download);
			break;
		
		case SFTP:
			sftpDownloader.download(downloadAttrs, download);
			break;
		
		case HTTP:
			httpDownloader.download(downloadAttrs, download);
			break;
		
		case HTTPS:
			httpsDownloader.download(downloadAttrs, download);
			break;
		
		default:
			throw new IllegalArgumentException("Protocol Not Supported");
		
		}
	}
}
