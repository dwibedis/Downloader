package com.zomato.download.downloader.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zomato.download.downloader.model.DownloadDTO;
import com.zomato.download.downloader.service.DownloadService;

/**
 * the API to download a file from the given URL.
 * 
 * @author zomato
 *
 */
@RestController
public class DownloadController {

	private static final Logger logger = LogManager.getLogger(DownloadController.class);

	@Autowired
	private DownloadService downloadService;

	/**
	 * API to download a file from specified location.
	 * 
	 * @param fileUrl specified location
	 * @return the status
	 */
	@GetMapping("/download")
	public DownloadDTO getFile(@RequestParam String fileUrl) {
		logger.info("Starting download.....");
		return downloadService.download(fileUrl);
	}
}
