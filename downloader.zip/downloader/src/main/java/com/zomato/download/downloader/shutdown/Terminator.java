package com.zomato.download.downloader.shutdown;

import java.util.List;

import javax.annotation.PreDestroy;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.zomato.download.downloader.entity.DownloadAbs;
import com.zomato.download.downloader.entity.Status;
import com.zomato.download.downloader.repository.DownloadRepo;

/**
 * utility to do pre shutdown actions.
 * 
 * @author zomato
 *
 */
@Component
public class Terminator {

	private static final Logger logger = LogManager.getLogger(Terminator.class);

	@Autowired
	private DownloadRepo downloadRepo;

	/**
	 * method to set all the progress and not started download as interrupted before
	 * server shutdown.
	 */
	@PreDestroy
	public void onDestroy() {
		
		logger.info("undergoing graceful shutdown.....");
		
		List<DownloadAbs> unDoneDownloads = downloadRepo.findByDownloadStatus(Status.IN_PROGRESS);
		unDoneDownloads.addAll(downloadRepo.findByDownloadStatus(Status.NOT_YET_STARTED));

		for (DownloadAbs download : unDoneDownloads) {
			download.setDownloadStatus(Status.INTERRUPTED);
		}
		
		downloadRepo.saveAll(unDoneDownloads);
	}
}
