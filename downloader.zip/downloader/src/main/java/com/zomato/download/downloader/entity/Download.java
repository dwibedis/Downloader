package com.zomato.download.downloader.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "download")
public class Download extends DownloadAbs{

}
