package com.zomato.download.downloader.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.zomato.download.downloader.entity.DownloadAbs;
import com.zomato.download.downloader.entity.Status;

/**
 * Repository to interact with download table.
 * 
 * @author zomato
 *
 */
public interface DownloadRepo extends CrudRepository<DownloadAbs, Long> {

	/**
	 * method to get the Download DTOs by the given status.
	 * 
	 * @param status the status
	 * @return the list of download DTOs
	 */
	public List<DownloadAbs> findByDownloadStatus(Status status);
}
