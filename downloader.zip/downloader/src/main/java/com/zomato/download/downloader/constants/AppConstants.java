package com.zomato.download.downloader.constants;

import java.util.HashMap;
import java.util.Map;

public class AppConstants {

	public static final String FILE_SEPARATOR = "/";
	public static final String FTP_SIZE_COMMAND = "SIZE";
	public static final String URL_SEPARATOR = "://";
	public static Map<Long, Long> FILE_SIZE_MAP = new HashMap<>();
}
