package com.zomato.download.downloader.protocols;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.zomato.download.downloader.model.Credentials;
import com.zomato.download.downloader.model.DownloadAttrs;
import com.zomato.download.downloader.utils.FileUtils;

/**
 * helper to fetch protocols.
 * 
 * @author zomato
 *
 */
@Service
public class DownloadAttrsHelper {

	@Value("${download.destination}")
	private String destination;

	private static final String URL_SPLITATOR = ":";

	/**
	 * method to return the protocol from given URL.
	 * 
	 * @param fileUrl
	 * @return the protocol
	 */
	public static Protocol getProtocol(String fileUrl) {
		String protocolStr = fileUrl.split(URL_SPLITATOR)[0].toUpperCase();
		try {
			return Protocol.valueOf(protocolStr);
		} catch (Exception e) {
			return Protocol.UNSUPPORTED;
		}
	}

	/**
	 * converts the URL to attrs DTO.
	 * 
	 * @param fileUrl  the given URL
	 * @param protocol the protocol
	 * @return attrs DTO
	 */
	public DownloadAttrs getDownloadAttrs(String fileUrl, Protocol protocol) {
		URI uri;
		try {
			uri = new URI(fileUrl);
		} catch (URISyntaxException e) {
			throw new IllegalArgumentException("Invalid URI syntax");
		}
		DownloadAttrs downloadAttrs = new DownloadAttrs();
		downloadAttrs.setHost(uri.getHost());
		downloadAttrs.setFileName(
				FileUtils.getAppropiateFile(new File(destination, new File(uri.getPath()).getName())).getName());
		downloadAttrs.setProtocol(protocol);
		downloadAttrs.setUrl(uri.getPath());
		downloadAttrs.setCredentials(getCredential(uri.getUserInfo()));
		return downloadAttrs;
	}

	private static Credentials getCredential(String string) {
		if (string == null) {
			return null;
		}
		Credentials cred = new Credentials();
		cred.setUsername(string.split(URL_SPLITATOR)[0]);
		cred.setPassword(string.split(URL_SPLITATOR)[1]);
		return cred;
	}
}
