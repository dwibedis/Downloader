package com.zomato.download.downloader.utils;

import java.io.File;

/**
 * file utility.
 * 
 * @author zomato
 *
 */
public class FileUtils {

	/**
	 * method to return appropiate file when copies are present.
	 * 
	 * @param file
	 * @return
	 */
	public static File getAppropiateFile(File file) {
		
		int counter = 1;
		String fileName = file.getName();
		
		while (file.exists()) {
			file = new File(file.getParent(),
					getFileNameWithoutExtension(fileName) + "_" + counter++ + "." + getFileExtension(fileName));
		}
		
		return file;
	
	}

	private static String getFileExtension(String name) {
		return name.split("\\.")[1];
	}

	private static String getFileNameWithoutExtension(String name) {
		return name.split("\\.")[0];
	}
}
