package com.zomato.download.downloader.service.impl;

import java.io.File;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.zomato.download.downloader.constants.AppConstants;
import com.zomato.download.downloader.model.DownloadDTO;
import com.zomato.download.downloader.service.StatusService;

@Service
public class StatusServiceImpl implements StatusService {

	@Value("${download.destination}")
	private String destination;

	@Override
	public int getStatus(DownloadDTO download) {
		File file = new File(destination, download.getFileName());
		long fileSize = 0;
		if (AppConstants.FILE_SIZE_MAP.containsKey(download.getDownloadId())) {
			fileSize = AppConstants.FILE_SIZE_MAP.get(download.getDownloadId());
		} else {
			return 100;
		}
		return (int) ((((double) file.length()) / ((double) fileSize)) * 100);
	}

}
