package com.zomato.download.downloader.model;

import com.zomato.download.downloader.protocols.Protocol;

/**
 * the model for storing download attributes from a given URL.
 * 
 * @author zomato
 *
 */
public class DownloadAttrs {

	private Protocol protocol;
	private Credentials credentials;
	private String host;
	private String fileName;
	private String url;

	public Protocol getProtocol() {
		return protocol;
	}

	public void setProtocol(Protocol protocol) {
		this.protocol = protocol;
	}

	public Credentials getCredentials() {
		return credentials;
	}

	public void setCredentials(Credentials credentials) {
		this.credentials = credentials;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

}
